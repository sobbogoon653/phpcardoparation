-- phpMyAdmin SQL Dump
-- version 4.8.0.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 10, 2019 at 05:57 PM
-- Server version: 10.1.32-MariaDB
-- PHP Version: 7.0.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `companydb`
--

-- --------------------------------------------------------

--
-- Table structure for table `companytbl`
--

CREATE TABLE `companytbl` (
  `id` int(11) NOT NULL,
  `fname` varchar(200) NOT NULL,
  `lname` varchar(200) NOT NULL,
  `mobile` varchar(50) NOT NULL,
  `address` varchar(500) NOT NULL,
  `propic` varchar(500) NOT NULL,
  `signuptime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `companytbl`
--

INSERT INTO `companytbl` (`id`, `fname`, `lname`, `mobile`, `address`, `propic`, `signuptime`) VALUES
(25, 'Shobbo Sachi', 'Goon', ' 01777589653', 'Sirajganj Sader, Sirajganj -6700', '5c85325df1072.jpg', '2019-03-10 15:50:53'),
(26, 'Md. Anwar', 'Hossain', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c85328780e69.jpg', '2019-03-10 15:51:35'),
(27, 'Md. Sobuj ', 'Islam', ' 019199995555', 'Sirajganj Sader, Sirajganj -6700', '5c85329a4510b.jpg', '2019-03-10 15:51:54'),
(28, 'Mst. Bristy', 'Khatun', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c8532b0a77af.jpg', '2019-03-10 15:52:16'),
(29, 'Mst. Reshma', 'Khatun', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c8532c0c5f79.jpg', '2019-03-10 15:52:32'),
(30, 'Md. Shariful ', 'Islam', ' 019199995555', 'Sirajganj Sader, Sirajganj -6700', '5c8532fd9de54.jpg', '2019-03-10 15:53:33'),
(31, 'Md. Imran ', 'Hossain', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c85330ac52b0.jpg', '2019-03-10 15:53:46'),
(32, 'Mst. Ananna ', 'Rahman', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c853325579bd.jpg', '2019-03-10 15:54:13'),
(33, 'Mst. Amina', 'Khatun', ' 019111111111', 'Sirajganj Sader, Sirajganj -6700', '5c85333adc5d9.jpg', '2019-03-10 15:54:34'),
(34, 'Probir Kumar', 'Saha', ' 01700000000', 'Sirajganj Sader, Sirajganj -6700', '5c853392ccf97.jpg', '2019-03-10 15:56:02'),
(35, 'Subir Chandra', 'Sarker', ' 019111111111', 'Sirajganj Sader, Sirajganj-6700', '5c853b731fbd0.jpg', '2019-03-10 16:30:02');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `companytbl`
--
ALTER TABLE `companytbl`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `companytbl`
--
ALTER TABLE `companytbl`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=36;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
